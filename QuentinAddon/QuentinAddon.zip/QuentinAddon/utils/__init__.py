from . import asset
from .asset import add_split_normals, clear_split_normals, duplicate_objects, prep_objects_for_combine, combine_objects_by_parent, mark_as_finished, clear_custom_normals_selection, testing_code
